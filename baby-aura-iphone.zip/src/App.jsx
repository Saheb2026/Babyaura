import React, { useState } from "react";

// Baby Aura — Single-file React app
// Tailwind CSS utility classes are used for styling (no imports needed here in canvas preview)
// This file exports a default React component you can drop into a Create React App / Vite + Tailwind

const brandPalette = {
  primary: "#f472b6",
  secondary: "#93c5fd",
  soft: "#fff7fb",
  accent: "#fbcfe8",
};

const SAMPLE_PRODUCTS = [
  { id: "p1", name: "Organic Cotton Baby Swaddle", price: 59, short: "Soft, breathable swaddle", image: "https://images.unsplash.com/photo-1583947581490-7b86db28b2a8?q=80&w=800&auto=format&fit=crop", description: "Premium organic cotton swaddle. Hypoallergenic, machine washable." },
  { id: "p2", name: "2-in-1 Baby Bottle Warmer", price: 129, short: "Fast & safe bottle warming", image: "https://images.unsplash.com/photo-1582719478180-2c04f6b5a0a9?q=80&w=800&auto=format&fit=crop", description: "Compact bottle warmer with auto shut-off." },
  { id: "p3", name: "Non-slip Baby Bath Mat", price: 39, short: "Safety-first bath padding", image: "https://images.unsplash.com/photo-1515879218367-8466d910aaa4?q=80&w=800&auto=format&fit=crop", description: "Quick-dry mat with strong suction pads." },
  { id: "p4", name: "Silicone Feeding Spoon Set", price: 25, short: "Soft on gums — BPA free", image: "https://images.unsplash.com/photo-1541029738-5f2f1b8f1b6b?q=80&w=800&auto=format&fit=crop", description: "Gentle silicone spoons for first foods." },
  { id: "p5", name: "Portable Change Mat", price: 45, short: "Foldable & water-resistant", image: "https://images.unsplash.com/photo-1527646558-9a8a6a1b6d6c?q=80&w=800&auto=format&fit=crop", description: "Easy-clean change mat for travel." },
  { id: "p6", name: "Ultra-Soft Muslin Towels (3pcs)", price: 69, short: "Breathable & absorbent", image: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=800&auto=format&fit=crop", description: "Large muslin towels for versatile use." },
  { id: "p7", name: "Gentle Baby Shampoo", price: 29, short: "Tear-free, natural extracts", image: "https://images.unsplash.com/photo-1556228573-8bd1d3c3b0f1?q=80&w=800&auto=format&fit=crop", description: "Dermatologically tested baby shampoo." },
  { id: "p8", name: "Adjustable Baby Carrier", price: 199, short: "Comfort for parent & baby", image: "https://images.unsplash.com/photo-1519744792095-2f2205e87b6f?q=80&w=800&auto=format&fit=crop", description: "Ergonomic carrier supports newborn to toddler." },
  { id: "p9", name: "Safety Corner Guards (8pcs)", price: 19, short: "Prevent bumps & bruises", image: "https://images.unsplash.com/photo-1582719478180-3c04f6b5a0a9?q=80&w=800&auto=format&fit=crop", description: "Soft PVC corner guards — easy stick-on." },
  { id: "p10", name: "BPA-free Drinking Cup", price: 22, short: "Spill-proof, easy-hold", image: "https://images.unsplash.com/photo-1542736667-069246bdbc97?q=80&w=800&auto=format&fit=crop", description: "Sippy cup with soft spout and handle." },
  { id: "p11", name: "Portable White Noise Machine", price: 99, short: "Soothing sounds for sleep", image: "https://images.unsplash.com/photo-1508873699372-7ae8c6f7b9cd?q=80&w=800&auto=format&fit=crop", description: "Compact white-noise device with adjustable volume." },
  { id: "p12", name: "Zip-up Sleepsuit (0-6 months)", price: 55, short: "Cozy & easy-change zipper", image: "https://images.unsplash.com/photo-1520975911256-146b2b7a1a8c?q=80&w=800&auto=format&fit=crop", description: "Soft cotton sleepsuit with two-way zipper." },
];

function Logo({ size = 48 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg" aria-label="Baby Aura logo">
      <rect width="64" height="64" rx="12" fill="#fff" />
      <g transform="translate(8,8)">
        <circle cx="16" cy="16" r="16" fill="#fdf2f8" />
        <path d="M10 24c4-6 14-6 18 0" stroke="#f472b6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" />
        <circle cx="12" cy="14" r="1.8" fill="#f472b6" />
        <circle cx="20" cy="12" r="2.2" fill="#93c5fd" />
      </g>
    </svg>
  );
}

function Navbar({ onNavigate, cartCount }) {
  return (
    <header className="bg-white/90 backdrop-blur sticky top-0 z-30 shadow-sm">
      <nav className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-3 cursor-pointer" onClick={() => onNavigate("home")}>
            <Logo size={40} />
            <div className="font-extrabold text-2xl tracking-tight text-pink-600">Baby Aura</div>
          </div>
          <div className="hidden md:flex items-center gap-2 text-sm text-gray-600">
            <button onClick={() => onNavigate("shop")} className="py-2 px-3 hover:underline">Shop</button>
            <button onClick={() => onNavigate("categories")} className="py-2 px-3 hover:underline">Categories</button>
            <button onClick={() => onNavigate("about")} className="py-2 px-3 hover:underline">About</button>
            <button onClick={() => onNavigate("contact")} className="py-2 px-3 hover:underline">Contact</button>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-sm text-gray-600 hidden sm:block">Sharjah • 0508609706</div>
          <button onClick={() => onNavigate("cart")} className="relative bg-pink-600 text-white px-3 py-2 rounded-lg text-sm shadow">
            Cart
            <span className="ml-2 inline-block bg-blue-600 text-white text-xs px-2 py-0.5 rounded-full">{cartCount}</span>
          </button>
        </div>
      </nav>
    </header>
  );
}

function Hero({ onNavigate }) {
  return (
    <section className="bg-gradient-to-r from-blue-50 to-pink-50 py-16">
      <div className="max-w-6xl mx-auto px-4 grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl font-bold">Premium Baby Essentials for Comfort &amp; Care</h1>
          <p className="mt-4 text-gray-700">Soft, safe and curated products designed to make parenting easier.</p>

          <div className="mt-6 flex gap-3">
            <button onClick={() => onNavigate("shop")} className="px-5 py-3 bg-pink-600 text-white rounded-lg shadow">
              Shop Now
            </button>
            <button onClick={() => onNavigate("about")} className="px-5 py-3 rounded-lg border">
              Learn More
            </button>
          </div>
        </div>
        <div className="rounded-lg overflow-hidden shadow-lg">
          <img src="https://images.unsplash.com/photo-1533418212168-2f8bc5b6d5a9?q=80&w=1200&auto=format&fit=crop" alt="happy baby" className="w-full h-72 object-cover" />
        </div>
      </div>
    </section>

function ProductCard({ product, onView, onAdd }) {
  return (
    <div className="border rounded-lg p-4 flex flex-col bg-white">
      <div className="h-40 rounded overflow-hidden bg-pink-50">
        <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
      </div>
      <h3 className="mt-3 font-semibold">{product.name}</h3>
      <p className="text-sm text-gray-600">{product.short}</p>
      <div className="mt-3 flex items-center justify-between">
        <div className="font-bold">AED {product.price}</div>
        <div className="flex gap-2">
          <button onClick={() => onView(product)} className="px-3 py-1 border rounded">View</button>
          <button onClick={() => onAdd(product)} className="px-3 py-1 bg-pink-600 text-white rounded">Add</button>
        </div>
      </div>
    </div>
  );
}

function Categories() {
  const cats = ["Feeding", "Bathing", "Toys", "Travel", "Safety", "Clothing", "Sleep", "Feeding Accessories"];
  return (
    <section className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-3xl font-bold text-pink-600 mb-6">Baby Aura Categories</h1>
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
        {cats.map((c) => (
          <div key={c} className="bg-white shadow rounded-xl p-6 text-center font-semibold">{c}</div>
        ))}
      </div>
    </section>
  );
}

function Shop({ products, onView, onAdd }) {
  return (
    <section className="max-w-6xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-bold mb-6">Shop</h2>
      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
        {products.map((p) => (
          <ProductCard key={p.id} product={p} onView={onView} onAdd={onAdd} />
        ))}
      </div>
    </section>
  );
}

function About() {
  return (
    <section className="bg-white py-12">
      <div className="max-w-4xl mx-auto px-4">
        <h2 className="text-2xl font-bold">About Baby Aura</h2>
        <p className="mt-4 text-gray-700">We specialise in premium baby products combining safety standards with luxurious feel. Based in Sharjah, our goal is to make parenting easier and safer.</p>

        <div className="mt-6 grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-4 border rounded">
            <h3 className="font-semibold">Our Promise</h3>
            <p className="text-sm text-gray-600 mt-2">Carefully sourced, safety tested, and parent approved.</p>
          </div>
          <div className="p-4 border rounded">
            <h3 className="font-semibold">Fast Support</h3>
            <p className="text-sm text-gray-600 mt-2">Contact us at 0508609706 or visit our Sharjah store.</p>
          </div>
        </div>
      </div>
    </section>
  );
}

function Contact() {
  return (
    <section className="max-w-4xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-bold">Contact</h2>
      <p className="mt-2 text-gray-600">Sharjah • Phone: 0508609706</p>
      <form className="mt-6 grid grid-cols-1 gap-4">
        <input placeholder="Your name" className="p-3 border rounded" />
        <input placeholder="Your email" className="p-3 border rounded" />
        <textarea placeholder="Message" className="p-3 border rounded" rows={5} />
        <div>
          <button className="px-5 py-3 bg-pink-600 text-white rounded">Send Message</button>
        </div>
      </form>
    </section>
  );
}

function Cart({ items, onRemove, onCheckout }) {
  const total = items.reduce((s, it) => s + it.price * it.qty, 0);
  return (
    <section className="max-w-4xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-bold">Your Cart</h2>
      {items.length === 0 ? (
        <p className="mt-4 text-gray-600">Your cart is empty.</p>
      ) : (
        <div className="mt-4 space-y-4">
          {items.map((it) => (
            <div key={it.id} className="flex items-center justify-between border rounded p-3">
              <div className="flex items-center gap-4">
                <img src={it.image} alt={it.name} className="w-16 h-16 object-cover rounded" />
                <div>
                  <div className="font-semibold">{it.name}</div>
                  <div className="text-sm text-gray-600">Qty: {it.qty}</div>
                </div>
              </div>
              <div className="text-right">
                <div className="font-bold">AED {it.price * it.qty}</div>
                <button onClick={() => onRemove(it.id)} className="text-sm text-red-600 mt-2">Remove</button>
              </div>
            </div>
          ))}

          <div className="text-right">
            <div className="text-lg font-bold">Total: AED {total}</div>
            <div className="mt-3">
              <button onClick={onCheckout} className="px-5 py-3 bg-emerald-600 text-white rounded">Checkout</button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

function Checkout({ items, onConfirm }) {
  const total = items.reduce((s, it) => s + it.price * it.qty, 0);
  return (
    <section className="max-w-4xl mx-auto px-4 py-12">
      <h2 className="text-2xl font-bold">Checkout</h2>
      <p className="mt-3 text-gray-700">Total payable: AED {total}</p>
      <form
        onSubmit={(e) => {
          e.preventDefault();
          const form = e.target;
          const name = form.elements[0].value || "Customer";
          const phone = form.elements[1].value || "050";
          const address = form.elements[2].value || "Address";
          onConfirm({ name, phone, address });
        }}
        className="mt-6 grid grid-cols-1 gap-4"
      >
        <input name="fullname" placeholder="Full name" className="p-3 border rounded" required />
        <input name="phone" placeholder="Phone (050...)" className="p-3 border rounded" required />
        <input name="address" placeholder="Address" className="p-3 border rounded" required />
        <div>
          <button type="submit" className="px-5 py-3 bg-emerald-600 text-white rounded">Place Order</button>
        </div>
      </form>
    </section>
  );
}

function OrderSuccess({ order }) {
  return (
    <section className="max-w-4xl mx-auto px-4 py-16 text-center">
      <div className="bg-white shadow rounded-lg p-8">
        <h2 className="text-2xl font-bold text-pink-600 mb-3">Order Confirmed</h2>
        <p className="text-gray-700 mb-4">Thank you, {order.name}! Your order has been placed.</p>
        <div className="font-mono bg-gray-100 inline-block px-4 py-2 rounded">Order ID: {order.id}</div>
        <p className="mt-4 text-sm text-gray-600">We will contact you at {order.phone} with shipping details.</p>
      </div>
    </section>
  );
}

export default function LaxuaryAndSafetySite() {
  const [page, setPage] = useState("home");
  const [products] = useState(SAMPLE_PRODUCTS);
  const [selected, setSelected] = useState(null);
  const [cart, setCart] = useState([]);
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [orderInfo, setOrderInfo] = useState(null);

  function handleView(product) {
    setSelected(product);
    setPage("product");
  }

  function handleAdd(product) {
    setCart((c) => {
      const found = c.find((x) => x.id === product.id);
      if (found) {
        return c.map((x) => (x.id === product.id ? { ...x, qty: x.qty + 1 } : x));
      }
      return [...c, { ...product, qty: 1 }];
    });
  }

  function handleRemove(productId) {
    setCart((c) => c.filter((x) => x.id !== productId));
  }

  function handleCheckout() {
    setPage("checkout");
  }

  function confirmOrder(customer) {
    const id = `BA-${Date.now().toString().slice(-6)}`;
    const order = { id, name: customer.name, phone: customer.phone, items: cart, total: cart.reduce((s, it) => s + it.price * it.qty, 0) };
    setOrderInfo(order);
    setCart([]);
    setOrderPlaced(true);
    setPage("success");
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <Navbar onNavigate={setPage} cartCount={cart.reduce((s, i) => s + i.qty, 0)} />

      <main className="mt-6">
        {page === "home" && (
          <>
            <Hero onNavigate={setPage} />
            <section className="max-w-6xl mx-auto px-4 py-12">
              <h2 className="text-2xl font-bold mb-6">Featured</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6">
                {products.slice(0, 6).map((p) => (
                  <ProductCard key={p.id} product={p} onView={handleView} onAdd={handleAdd} />
                ))}
              </div>
            </section>
          </>
        )}

        {page === "shop" && <Shop products={products} onView={handleView} onAdd={handleAdd} />}
        {page === "categories" && <Categories />}
        {page === "about" && <About />}
        {page === "contact" && <Contact />}

        {page === "product" && selected && (
          <section className="max-w-4xl mx-auto px-4 py-12">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-2">
                <img src={selected.image} className="w-full h-96 object-cover rounded" alt={selected.name} />
              </div>
              <div>
                <h2 className="text-2xl font-bold">{selected.name}</h2>
                <p className="mt-2 text-gray-600">{selected.description}</p>
                <div className="mt-4 font-bold text-xl">AED {selected.price}</div>
                <div className="mt-4 flex gap-3">
                  <button onClick={() => handleAdd(selected)} className="px-4 py-2 bg-pink-600 text-white rounded">Add to cart</button>
                  <button onClick={() => setPage("shop")} className="px-4 py-2 border rounded">Back to shop</button>
                </div>
              </div>
            </div>
          </section>
        )}

        {page === "cart" && <Cart items={cart} onRemove={handleRemove} onCheckout={handleCheckout} />}

        {page === "checkout" && <Checkout items={cart} onConfirm={confirmOrder} />}

        {page === "success" && orderInfo && <OrderSuccess order={orderInfo} />}

        {orderPlaced && page !== "success" && (
          <div className="fixed bottom-6 right-6 bg-emerald-600 text-white px-4 py-3 rounded shadow">Thank you! Your order has been placed.</div>
        )}
      </main>

      <footer className="mt-12 bg-white border-t">
        <div className="max-w-6xl mx-auto px-4 py-8 flex flex-col md:flex-row justify-between items-start gap-6">
          <div>
            <div className="flex items-center gap-3">
              <Logo size={34} />
              <div>
                <div className="font-bold text-lg">Baby Aura</div>
                <div className="text-sm text-gray-600 mt-1">E-commerce baby products — Sharjah</div>
              </div>
            </div>
            <div className="text-sm text-gray-600 mt-2">Phone: 0508609706</div>
          </div>

          <div className="text-sm text-gray-600">
            <div className="font-semibold">Quick Links</div>
            <ul className="mt-2 space-y-1">
              <li onClick={() => setPage("shop")} className="cursor-pointer">Shop</li>
              <li onClick={() => setPage("about")} className="cursor-pointer">About</li>
              <li onClick={() => setPage("contact")} className="cursor-pointer">Contact</li>
            </ul>
          </div>

          <div className="text-sm text-gray-600">
            <div className="font-semibold">Policies</div>
            <ul className="mt-2 space-y-1">
              <li>Shipping & Returns</li>
              <li>Privacy Policy</li>
            </ul>
          </div>
        </div>
        <div className="text-center py-4 text-xs text-gray-500">© {new Date().getFullYear()} Baby Aura</div>
      </footer>
    </div>
  );
}
